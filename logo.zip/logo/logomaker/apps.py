from django.apps import AppConfig


class LogomakerConfig(AppConfig):
    name = 'logomaker'
